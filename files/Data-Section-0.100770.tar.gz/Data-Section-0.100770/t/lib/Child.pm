use strict;
use warnings;
package Child;
our $VERSION = '0.100770';
use Godfather;
use base qw(Parent Godfather);
1;
__DATA__
__[b]__
22
__[c]__
33
__[d]__
44
