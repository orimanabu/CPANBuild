use strict;
use warnings;
package NoData;
our $VERSION = '0.100770';
use Data::Section -setup;

1;
