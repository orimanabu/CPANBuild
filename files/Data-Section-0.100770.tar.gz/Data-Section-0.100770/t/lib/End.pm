use strict;
use warnings;
package End;
our $VERSION = '0.100770';
use Data::Section -setup;

1;

__DATA__

__[a]__
1
__[b]__
2
__END__

__[c]__
3
