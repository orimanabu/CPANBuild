package Simple1;

sub foo {}
sub bar {}
sub baz {}

1;
__END__

# test module - three subs, one without, one with an item, one with a head2

=head2 Methods

=over

=item foo

this is foo

=back

=head2 baz

baz is very important

=cut

