package Args;

sub foo {}

1;
__END__

# test module - one sub, documented with a head2 with sample arguments

=head2 foo($bar, @baz)

foo takes a bar and the rest of the stuff is an array of bazen
